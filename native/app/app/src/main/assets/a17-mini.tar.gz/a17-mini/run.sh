#!/bin/sh
# Run an Android 17 program from root/ directly on this phone's kernel.
#   ./run.sh toybox uname -a      ./run.sh sh      ./run.sh nboot
cd "$(dirname "$0")"
export ANDROID_NATIVE_ROOT="$PWD/root"
# Termux preloads its own helper (libtermux-exec); Android 17's linker would look for it in root/
unset LD_PRELOAD LD_LIBRARY_PATH
# Android's own environment (Termux's PATH points at folders the image doesn't have)
export PATH=/system/bin:/system/xbin HOME=/data/local/tmp TMPDIR=/data/local/tmp   ANDROID_ROOT=/system ANDROID_DATA=/data
# The kernel version programs see, at least (libc's uname()): Android 17's
# BPF loader wants 5.10, though BPF is emulated in libc here.
export ANDROID_NATIVE_KERNEL=5.10.240
# Android's boot environment in a full root (BOOTCLASSPATH, ...; a17root.py writes it)
[ -f "$ANDROID_NATIVE_ROOT/system/etc/native-env.sh" ] && . "$ANDROID_NATIVE_ROOT/system/etc/native-env.sh"
prog="$1"; shift
case "$prog" in /*) ;; *) prog="/system/bin/$prog" ;; esac
# Start it through the image's shell: its execve() runs dynamic programs through
# the image's linker and static ones (nprops) directly. Its current directory
# is the root's / (a directory outside the root has no path inside it).
cd "$ANDROID_NATIVE_ROOT"
exec "$ANDROID_NATIVE_ROOT/apex/com.android.runtime/bin/linker64" /system/bin/sh -c 'exec "$@"' sh "$prog" "$@"
